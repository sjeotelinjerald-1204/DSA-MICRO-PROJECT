# Cartwise — dataset-integrated shopping cart

This version uses the six supplied CSV files in `data/`: `products.csv`, `users.csv`, `orders.csv`, `order_items.csv`, `reviews.csv`, and `events.csv`. The product catalogue is populated from `products.csv`; a summary of dataset sizes and average order value is displayed on the shop page.

## Run locally
1. Install Python 3.10+
2. In this folder run `python -m pip install -r requirements.txt`
3. Run `python app.py`
4. Visit `http://127.0.0.1:5000`

The application is a local demo. Orders placed through the website are temporary demo orders and are not written back into the supplied CSVs. Customer data is not shown on the public page. The budget optimizer uses product ratings as a simple priority score and limits its candidate set for responsiveness.
