from flask import Flask, jsonify, request, render_template
from collections import deque
from copy import deepcopy
from pathlib import Path
import pandas as pd

app = Flask(__name__)
DATA_DIR = Path(__file__).parent / "data"

# Load the supplied dataset files. The product catalogue comes directly from products.csv.
products_df = pd.read_csv(DATA_DIR / "products.csv")
orders_df = pd.read_csv(DATA_DIR / "orders.csv")
order_items_df = pd.read_csv(DATA_DIR / "order_items.csv")
reviews_df = pd.read_csv(DATA_DIR / "reviews.csv")
events_df = pd.read_csv(DATA_DIR / "events.csv")
users_df = pd.read_csv(DATA_DIR / "users.csv")

ICONS = {"Electronics":"💻", "Clothing":"👕", "Groceries":"🛒", "Sports":"⚽", "Accessories":"🎒", "Audio":"🎧", "Home":"🏠", "Beauty":"✨", "Books":"📚", "Toys":"🧸"}
# Stable integer keys are used internally; original dataset product IDs remain visible in the UI.
PRODUCTS = {}
for row in products_df.to_dict(orient="records"):
    pid = str(row["product_id"])
    PRODUCTS[pid] = {
        "id": pid, "name": str(row["product_name"]), "category": str(row["category"]),
        "brand": str(row["brand"]), "price": round(float(row["price"]), 2),
        "rating": round(float(row.get("rating", 0) or 0), 2),
        "priority": max(1, min(10, round(float(row.get("rating", 3) or 3)))),
        "icon": ICONS.get(str(row["category"]), "🛍️"),
        "description": f"{row['brand']} · Rated {float(row.get('rating', 0) or 0):.1f}/5"
    }

class CartNode:
    def __init__(self, product_id, quantity):
        self.product_id, self.quantity, self.next = product_id, quantity, None

class ShoppingCart:
    def __init__(self):
        self.head = None; self.index = {}; self.undo_stack = []; self.order_queue = deque(); self.next_order_id = 1001
    def snapshot(self):
        items=[]; node=self.head
        while node: items.append((node.product_id,node.quantity)); node=node.next
        return items
    def save_undo(self):
        self.undo_stack.append(self.snapshot())
        if len(self.undo_stack)>30: self.undo_stack.pop(0)
    def restore(self, items):
        self.head=None; self.index={}; tail=None
        for pid,qty in items:
            node=CartNode(pid,qty)
            if self.head is None: self.head=node
            else: tail.next=node
            tail=node; self.index[pid]=node
    def add(self,pid,quantity=1):
        if pid not in PRODUCTS: raise ValueError("Product not found.")
        if quantity<1: raise ValueError("Quantity must be at least 1.")
        self.save_undo()
        if pid in self.index: self.index[pid].quantity += quantity
        else:
            node=CartNode(pid,quantity)
            if self.head is None: self.head=node
            else:
                tail=self.head
                while tail.next: tail=tail.next
                tail.next=node
            self.index[pid]=node
    def remove(self,pid):
        if pid not in self.index: raise ValueError("That product is not in the cart.")
        self.save_undo(); previous=None; current=self.head
        while current:
            if current.product_id==pid:
                if previous is None: self.head=current.next
                else: previous.next=current.next
                del self.index[pid]; return
            previous,current=current,current.next
    def update(self,pid,quantity):
        if pid not in self.index: raise ValueError("That product is not in the cart.")
        if quantity<1: return self.remove(pid)
        self.save_undo(); self.index[pid].quantity=quantity
    def undo(self):
        if not self.undo_stack: return False
        self.restore(self.undo_stack.pop()); return True
    def items(self):
        result=[]; node=self.head
        while node:
            product=PRODUCTS[node.product_id]; result.append({**product,"quantity":node.quantity,"line_total":round(product["price"]*node.quantity,2)}); node=node.next
        return result
    def total(self): return round(sum(i["line_total"] for i in self.items()),2)
    def checkout(self):
        if self.head is None: raise ValueError("Your cart is empty.")
        order={"order_id":self.next_order_id,"items":self.items(),"total":self.total(),"status":"Queued"}; self.next_order_id+=1
        self.order_queue.append(order); self.save_undo(); self.head=None; self.index={}; return order
    def process_next_order(self):
        if not self.order_queue: return None
        order=self.order_queue.popleft(); order["status"]="Processed"; return order
cart=ShoppingCart()

def merge_sort(items,key="price",descending=False):
    if len(items)<=1: return items[:]
    mid=len(items)//2; left=merge_sort(items[:mid],key,descending); right=merge_sort(items[mid:],key,descending); merged=[]; i=j=0
    while i<len(left) and j<len(right):
        take_left=left[i][key]>=right[j][key] if descending else left[i][key]<=right[j][key]
        if take_left: merged.append(left[i]); i+=1
        else: merged.append(right[j]); j+=1
    return merged+left[i:]+right[j:]

def optimize_cart(budget):
    # Use the 100 best-rated affordable candidates to keep the interactive demo responsive.
    candidates=[p for p in PRODUCTS.values() if p["price"]<=budget]
    candidates=sorted(candidates,key=lambda p:(p["rating"],-p["price"]),reverse=True)[:100]
    whole_budget=min(max(0,int(budget)),20000); dp=[0]*(whole_budget+1); chosen=[[] for _ in range(whole_budget+1)]
    for product in candidates:
        cost=int(round(product["price"]))
        for money in range(whole_budget,cost-1,-1):
            value=dp[money-cost]+product["priority"]
            if value>dp[money]: dp[money]=value; chosen[money]=chosen[money-cost]+[product]
    best=max(range(whole_budget+1),key=lambda b:dp[b]); selected=chosen[best]
    return {"items":selected,"spent":round(sum(p["price"] for p in selected),2),"value":sum(p["priority"] for p in selected),"budget":budget}

@app.get("/")
def home(): return render_template("index.html")
@app.get("/api/products")
def get_products():
    sort=request.args.get("sort","featured"); products=list(PRODUCTS.values())
    if sort=="price-low": products=merge_sort(products,"price")
    elif sort=="price-high": products=merge_sort(products,"price",True)
    elif sort=="name": products=sorted(products,key=lambda p:p["name"].lower())
    elif sort=="rating": products=sorted(products,key=lambda p:p["rating"],reverse=True)
    limit=max(1,min(int(request.args.get("limit",48)),2000)); page=max(1,int(request.args.get("page",1))); start=(page-1)*limit
    return jsonify({"products":products[start:start+limit],"total":len(products),"page":page,"limit":limit,"pages":(len(products)+limit-1)//limit})
@app.get("/api/analytics")
def analytics():
    category_counts=products_df["category"].value_counts().head(8).to_dict()
    return jsonify({"products":len(products_df),"users":len(users_df),"orders":len(orders_df),"order_items":len(order_items_df),"reviews":len(reviews_df),"events":len(events_df),"avg_rating":round(float(products_df.rating.mean()),2),"avg_order_value":round(float(orders_df.total_amount.mean()),2),"categories":[{"name":str(k),"count":int(v)} for k,v in category_counts.items()]})
@app.get("/api/cart")
def get_cart(): return jsonify({"items":cart.items(),"total":cart.total(),"undo_available":bool(cart.undo_stack),"item_count":sum(i["quantity"] for i in cart.items())})
@app.post("/api/cart/add")
def add_item():
    data=request.get_json(force=True)
    try: cart.add(str(data["product_id"]),int(data.get("quantity",1))); return get_cart()
    except (ValueError,KeyError) as e: return jsonify({"error":str(e)}),400
@app.post("/api/cart/update")
def update_item():
    data=request.get_json(force=True)
    try: cart.update(str(data["product_id"]),int(data["quantity"])); return get_cart()
    except (ValueError,KeyError) as e: return jsonify({"error":str(e)}),400
@app.post("/api/cart/remove")
def remove_item():
    data=request.get_json(force=True)
    try: cart.remove(str(data["product_id"])); return get_cart()
    except (ValueError,KeyError) as e: return jsonify({"error":str(e)}),400
@app.post("/api/cart/undo")
def undo():
    if not cart.undo(): return jsonify({"error":"There is no action to undo."}),400
    return get_cart()
@app.post("/api/checkout")
def checkout():
    try: order=cart.checkout(); return jsonify({"order":order,"cart":{"items":cart.items(),"total":cart.total(),"undo_available":bool(cart.undo_stack),"item_count":0}})
    except ValueError as e: return jsonify({"error":str(e)}),400
@app.get("/api/orders")
def orders(): return jsonify(list(cart.order_queue))
@app.post("/api/orders/process")
def process_order():
    order=cart.process_next_order()
    if order is None: return jsonify({"error":"There are no orders waiting to be processed."}),400
    return jsonify({"order":order,"remaining":len(cart.order_queue)})
@app.post("/api/optimize")
def optimize():
    data=request.get_json(force=True)
    try: budget=float(data.get("budget",5000))
    except (ValueError,TypeError): return jsonify({"error":"Enter a valid budget."}),400
    if budget<0 or budget>20000: return jsonify({"error":"For this demo, budget must be between ₹0 and ₹20,000."}),400
    return jsonify(optimize_cart(budget))
@app.post("/api/simulate")
def simulate():
    data=request.get_json(force=True)
    try:
        change=float(data.get("price_change",0)); delivery=float(data.get("delivery",0)); budget=float(data.get("budget",5000))
        if change < -90 or change>200 or delivery<0 or budget<0: raise ValueError
    except (ValueError,TypeError): return jsonify({"error":"Use a price change from -90% to 200%, and non-negative delivery and budget values."}),400
    items=cart.items(); subtotal=round(sum(round(i["line_total"]*(1+change/100),2) for i in items),2); total=round(subtotal+delivery,2)
    return jsonify({"subtotal":subtotal,"delivery":delivery,"total":total,"budget":budget,"remaining":round(budget-total,2),"within_budget":total<=budget,"price_change":change})
if __name__=="__main__": app.run(debug=True)
